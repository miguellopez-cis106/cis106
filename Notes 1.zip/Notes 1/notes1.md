# Notes 1

## What is Markdown?
Markdown is a lightweight markup language that is used in writing, programming, and web development. Markdown was meant to create syntax to make it easy to read for humans' eyes and machine. Markdown is used in web development, content writing, and documenting. It enables easy creation of links, lists, images, headers, and tables that can generate into polished documents without using Microsoft document. 
## What is Git?
Git is a tool to manage changes of the files, also the code of the projects. It is called source control because of it allows multiple people to work on the same project. If ran into bug or someone deleted a file by accident, the project is saved back to previous, it reduces stress and saves someone's time when running into issues. 
## What is GitHub?
GitHub is where people share, grow, and collaborate through code and ideas. Github is used to place your work online, tools to contribute to other people's projects, a home for personal projects, and doucmentation. This is a connection to a global open source community. Github is useful in real life, three people who are working on your project can have access to it without emailing files back and forth or copy-pasting into one folder.
## What is Slack?
Slack is an app where people can commmunicate to each other and stay in contact when working on an assignment or project. If anyone is stuck on an assigment or confused, they can ask for help through the Slack app. Instead of relying on email, this app can be used to communicate then. It is almost like discord, but in a professional way. 